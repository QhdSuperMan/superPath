export default {
  getRouterBoxs: state => state.routerBoxs,
  getVisitedViews: state => state.visitedViews
}