import { routerBoxs } from '@/router/index.js'
export default {
  routerBoxs: routerBoxs, // 路由,
  visitedViews: [],  // 标签
}