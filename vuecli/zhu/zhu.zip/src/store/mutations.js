export default {
  setVisitedViews (state, box) { // 设置标签
    state.visitedViews = box
  }
}