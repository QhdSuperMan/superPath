<template>
	<el-header class="heaer">
		头部
	</el-header>
</template>

<script>
	export default {};
</script>

<style lang='less' scoped>
	.heaer {
		background-color: #9b9baf;
	}
</style>

<style lang="less">
	#app {
		.el-header {
			padding: 0px;
		}
	}
</style>