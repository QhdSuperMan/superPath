<template>
	<router-view />
</template>
