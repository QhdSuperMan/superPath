<template>
	<div>
		用户新增
	</div>
</template>

<script>
	export default {
    created () {
      console.log(11)
    }
  };
</script>

<style>
</style>