<template>
	<div>
		权限新增
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>