<template>
	<div>
		权限列表
	</div>
</template>

<script>
	export default {};
</script>

<style>
</style>