'use strict';

export default {
  nunjucks: {
    enable: true,
    package: 'egg-view-nunjucks',
  },
};
