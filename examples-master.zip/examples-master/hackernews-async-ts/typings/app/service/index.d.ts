// This file was auto created by egg-ts-helper
// Do not modify this file!!!!!!!!!

import News from '../../../app/service/News';

declare module 'egg' {
  interface IService {
    news: News;
  }
}
