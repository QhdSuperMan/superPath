declare module 'egg' {

}