'use strict';

module.exports = {
  test: '123',
};
