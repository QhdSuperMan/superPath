# unittest-jest

Example use on https://github.com/eggjs/egg/blob/master/docs/source/zh-cn/core/unittest.md
