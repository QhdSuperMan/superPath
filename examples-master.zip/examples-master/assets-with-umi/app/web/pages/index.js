import Home from './home/index';
export default Home;
