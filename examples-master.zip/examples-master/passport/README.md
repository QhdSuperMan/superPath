# egg-passport example

- Index: http://127.0.0.1:7001/
- Auth Strategies
  - Weibo: http://127.0.0.1:7001/passport/weibo
  - GitHub: http://127.0.0.1:7001/passport/github
  - Bitbucket: http://127.0.0.1:7001/passport/bitbucket
  - Twitter: http://127.0.0.1:7001/passport/twitter
  - YuQue: http://127.0.0.1:7001/passport/yuque
