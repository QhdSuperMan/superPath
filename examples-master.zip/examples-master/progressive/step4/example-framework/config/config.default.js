'use strict';

exports.framework = {
  name: 'example-framework',
};
