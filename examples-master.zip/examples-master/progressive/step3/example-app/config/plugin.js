'use strict';

exports.ua = {
  enable: true,
  package: 'egg-ua',
};
