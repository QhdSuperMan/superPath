'use strict';

module.exports = {
  keys: 'sit keys',
};
