'use strict';

exports.keys = 'my super cool keys';

exports.middleware = [
  'hello',
];

exports.hello = {
  text: 'Hello World',
};
