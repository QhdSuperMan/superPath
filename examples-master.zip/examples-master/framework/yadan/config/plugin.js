'use strict';

// add you build-in plugin here, example:
exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks',
};
