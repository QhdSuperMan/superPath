'use strict';

exports.static = true;
