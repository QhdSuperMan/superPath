'use strict';

exports.keys = 'my cooo00ooooool keys';
exports.security = {
  csrf: false,
  ctoken: false,
};
