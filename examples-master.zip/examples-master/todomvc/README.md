# TodoMVC powered by Egg

- [TodoMVC](http://todomvc.com/)
- [Egg](egg)

![](./todomvc.png)

### QuickStart

```bash
$ npm i
$ npm run dev
$ open http://localhost:7001/
```

[egg]: https://eggjs.org
