'use strict';

module.exports = app => {
  app.router.get('/', 'api.index');
};
