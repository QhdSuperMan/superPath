'use strict';

exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks',
};

