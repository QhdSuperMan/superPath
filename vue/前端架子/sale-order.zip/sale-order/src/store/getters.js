export default {
  getToken: (state) => state.token,
  getRoutes: (state) => state.routes,
  getUserInfo: (state) => state.userInfo,
  getDevice: (state) => state.device,
  getSidebarMenu: (state) => state.sidebarMenu,
  getBtnAuthority: (state) => state.btnAuthority,
};
