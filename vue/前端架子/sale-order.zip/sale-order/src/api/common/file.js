// 上传 下载操作文件api
export default {
  resourceDownload: "/admin/resource/downloadTemplate", // 资源下载模板下载模板
  resourceImport: "/admin/resource/import", // 资源下载模板上传
};
