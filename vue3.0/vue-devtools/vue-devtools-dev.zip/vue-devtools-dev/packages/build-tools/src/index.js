Object.assign(module.exports, {
  ...require('./createConfig')
})
