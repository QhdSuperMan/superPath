import Button from './button'
Button.install = (Vue) => {
  Vue.component(Button.name, Button)
}

export default Button
