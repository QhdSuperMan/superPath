import Input from './input'
Input.install = (Vue) => {
  Vue.component(Input.name, Input)
}

export default Input
