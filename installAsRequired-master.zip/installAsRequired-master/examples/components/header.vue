<template lang="html">
  <div class="header-model">
    <h1 class="info">
      通用组件库
    </h1>
  </div>
</template>

<script>
export default {
  data () {
    return {
    }
  }
}
</script>
