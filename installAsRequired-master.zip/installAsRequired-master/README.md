## 按需加载
借助babel插件`babel-plugin-component`实现

详细查看点击下方链接
[segmentFault](https://segmentfault.com/a/1190000015884948)

## markdown编写说明文档

详细查看点击下方链接
[segmentFault](https://segmentfault.com/a/1190000016342795)

## 为组件库增加单元测试
详细查看点击下方链接
[segmentFault](https://segmentfault.com/a/1190000017970919)